# APICalculator
Simple android calculator using math.js API written in Kotlin 
